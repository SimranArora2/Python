#Board Of Game
Board =[["Br", "Bp", "", "" ,"", "", "Wp", "Wr"],
	["Bn", "Bp", "", "" ,"", "", "Wp", "Wn"],
	["Bb", "Bp", "", "" ,"", "", "Wp", "Wb"],
	["Bq", "Bp", "", "" ,"", "", "Wp", "Wq"],
	["Bk", "Bp", "", "" ,"", "", "Wp", "Wk"],
	["Bb", "Bp", "", "" ,"", "", "Wp", "Wb"],
	["Bn", "Bp", "", "" ,"", "", "Wp", "Wn"],
	["Br", "Bp", "", "" ,"", "", "Wp", "Wr"]]

#Geometry Of Borad
Width = 560
Height = 660
Board_Height = 560
Difference = Height - Board_Height

#Size Of Board
Box_Size = Width/8
