from translate import Translator
translator= Translator(from_lang="german",to_lang="en")
translation = translator.translate("Guten Morgen")
print(translation)