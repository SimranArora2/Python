# Schedule Library imported 
import schedule 
import time 
from webbrowser import open
import pyautogui as aa
from time import sleep
  
# Functions setup 
def maths():
    open('https://cuchd.blackboard.com/ultra/course') 
    sleep(6)
    aa.press('tab')
    sleep(1)
    aa.press('enter')
    sleep(1)
    aa.press('tab')
    sleep(1)
    sleep(1)
    aa.press('tab')
    sleep(1)
    aa.press('tab')
    sleep(1)
    aa.press('tab')
    sleep(1)
    aa.press('tab')
    sleep(1)
    aa.typewrite('math')
    sleep(1)
    aa.press('tab')
    sleep(1)
    aa.press('enter')
    sleep(1)
    aa.press('tab')
    sleep(1)
    aa.press('tab')
    sleep(1)
    aa.press('tab')
    sleep(1)
    aa.press('enter')
    sleep(1)
    aa.press('tab')
    sleep(1)
    aa.press('enter')
    sleep(1)
    aa.press('tab')
    sleep(1)
    aa.press('tab')
    sleep(1)
    aa.press('enter')
    sleep(1)
    aa.press('tab')
    sleep(1)
    aa.press('enter')
    sleep(1)
     
  
def good_luck(): 
    print("Good Luck for Test") 
  
def work(): 
    print("Study and work hard") 
  
def bedtime(): 
    print("It is bed time go rest") 
      
def geeks(): 
    print("Shaurya says Geeksforgeeks") 
  
# Task scheduling 
# After every 10mins geeks() is called.  
schedule.every(1).minutes.do(geeks) 
  
# After every hour geeks() is called. 
schedule.every().hour.do(geeks) 
  
# Every day at 12am or 00:00 time bedtime() is called. 
schedule.every().day.at("00:00").do(bedtime) 
  
# After every 5 to 10mins in between run work() 
schedule.every(1).to(10).minutes.do(work) 
  
# Every monday good_luck() is called 
schedule.every().monday.do(good_luck) 
  
# Every tuesday at 18:00 sudo_placement() is called 
schedule.every().monday.at("14:14").do(maths) 
  
# Loop so that the scheduling task 
# keeps on running all time. 
while True: 
  
    # Checks whether a scheduled task  
    # is pending to run or not 
    schedule.run_pending() 
    time.sleep(1)