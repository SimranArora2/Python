# snake_game
It Is a Great Snake Game.
It is written in Python and anyone can understand the code of this game.
It is build using the pygame module.
I made this code for fun.

To Start Playing:
  
First install the pygame module then Run the snake.py file.

To Pause Game press 'p' on your keyboard.

SO ENJOY THIS GAME, YOU WILL LIKE IT VERY MUCH!!!!
