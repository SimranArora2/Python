
import pyautogui as pg
from pyttsx3 import speak
from time import sleep

def get_command(to_be_removed,text):
    text=str(text)
    return text.replace(to_be_removed,'')

def locationerrorfixer(address):
    address=str(address)
    return address.replace('\\','\\\\')

def send_email():
    from webbrowser import open
    import pyautogui as aa
    from time import sleep
    speak('To whom you want to send the Email')
    receiver=recognize_said_words()
    speak('speak the subject')
    subject=recognize_said_words()
    speak('speak the content')
    content=recognize_said_words()
    open("https://mail.google.com/mail/u/0/#inbox")
    sleep(5)
    sleep(1)
    aa.press('d')
    sleep(4)
    aa.typewrite(receiver)
    sleep(2)
    aa.press('tab')
    sleep(2)
    aa.press('tab')
    sleep(2)
    aa.typewrite(subject)
    sleep(2)
    aa.press('tab')
    sleep(1)
    aa.typewrite(content)
    sleep(1)
    aa.hotkey('ctrlleft','enter')
    speak('email sent succesfully ')
        

def recognize_said_words():
    import speech_recognition as sr     #import module named as speech_recognition with name sr
    r = sr.Recognizer()    #recognize the source used for speech recognition purpose
    mic = sr.Microphone(device_index=1)     #indexing micophone
    with mic as source:
        r.adjust_for_ambient_noise(source,duration=1)   #adjust to remove noise
        print("Start saying something")
        audio=r.listen(source,timeout=40)    # starts listening
    try:
        speak("you said"+r.recognize_google(audio))   #print the text spoken
        print("you said:"+r.recognize_google(audio))
        return r.recognize_google(audio)
    except:     #if try fails then this part runs
        speak("sry, didn't get what you said, please repeat")
        print("sry, didn't get what you said, please repeat")
        return recognize_said_words()   #print sry if didn't get what one speaks


def run_this():
    #isEntryAllowed=False
    input_command=recognize_said_words()
    if 'hey jarvis' or 'hi jarvis' or 'hello jarvis' or 'jarvis' == input_command:
        #recognize using username and password
        speak('are you an old user')
        print("are you an old user")
        old_user_or_not=recognize_said_words()
        if 'yes' in old_user_or_not:
            speak('speak your username')
            print("speak your username")
            username=recognize_said_words()
            speak('speak your password')
            print("speak your password")
            password=recognize_said_words()
            try:
                filename = open(r'c:\\Users\\HH\\Desktop\\JARVIS\\{}password.txt'.format(username),"r")
                str = filename.readline()
                if password in str:
                    isEntryAllowed = True
                    commands(isEntryAllowed=True)
                else:
                    speak('entry not allowed')
                    isEntryAllowed = False
                    commands(isEntryAllowed=False)
                    run_this()
                filename.close()
            except Exception as e:
                print(e)
                run_this()
        elif 'no' in old_user_or_not:
            speak("to continue you need to signup day yes if you want to continue else no")
            print("to continue you need to signup day yes if you want to continue else no")
            want_to_signup_or_not=recognize_said_words()
            if 'yes' in want_to_signup_or_not:
                speak("enter new username")
                print("enter new username")
                new_user_name = recognize_said_words()
                speak('enter new password')
                print("enter new password")
                new_password = recognize_said_words()
                filename = open(r'c:\\Users\\HH\\Desktop\\JARVIS\\{}.txt'.format(new_user_name),"a+")
                str1 = filename.readline()
                print(filename.write(new_user_name+"\n"),end='')
                filename.close()
                filename = open(r'C:\\Users\\HH\\Desktop\\JARVIS\\{}password.txt'.format(new_user_name),"a+")
                str2 = filename.readline()
                print(filename.write(new_password+"\n"),end='')
                filename.close()
                speak('now you have to sign in to use our service')
                print("now you have to sign in to use our service")
                run_this()
            elif 'no' in want_to_signup_or_not:
                speak('sorry sir then you will be unable to continue')
                print("sorry sir then you will be unable to continue")
            else:
                speak('enter valid input')
                print("enter valid input")
                run_this()
        else:
            speak('enter valid input')
            print("enter valid input")
            run_this()
    else:
        speak('enter valid input')
        print("enter valid input")
        run_this()

def commands(isEntryAllowed=False):
    speak('Welcome sir')
    print("Welcome sir")
    hourA=0
    minA=0
    import datetime
    import datefinder
    import winsound
    while isEntryAllowed==True:
        if hourA == datetime.datetime.now().hour:
            if minA == datetime.datetime.now().minute:
                print("your alarm rang")
                winsound.PlaySound('audio file')
        print("what you want me to do for you sir")
        speak('what you want me to do for you sir')
        user_input = recognize_said_words()
        if 'search for Wi-Fi' in user_input:
            print("searching for wifi")
            speak('searching for wifi')
            from os import system
            system('netsh wlan show profiles')
        elif 'connect to nearby network' in user_input:
            print("connecting to nearby network")
            speak('connecting to nearby network')
            from os import system
            system('netsh wlan connect name="vivo Y21L"')
            # wifi password cracker=Vikram 
        elif 'play snake game' in user_input:
            print("going to play snake game")
            speak('going to play snake game')
            from os import system
            system('python snake.py')
            #snake game=Dikshant
        elif 'play' and 'on youtube' in user_input:
            print("playing")
            speak('playing')
            from pywhatkit import playonyt
            song_name=get_command('play ',user_input)
            final_name=get_command(' on youtube',user_input)
            #Play song on youtube=Simran
            playonyt(final_name)
        elif 'open' in user_input:
            from time import sleep
            from pyautogui import press,typewrite
            user_input=list(user_input)
            new_user_input=str(get_command('open ',user_input))
            press('win')
            sleep(2)
            typewrite(new_user_input)
            sleep(2)
            press('enter')
            #→ Opening any installed application=Vikram
        elif 'send message on WhatsApp' in user_input:
            from pywhatkit import sendwhatmsg
            print("speak mobile no to which you want to send")
            speak('speak mobile no to which you want to send')
            phone_number=int(recognize_said_words())
            phone_number=str(phone_number)
            phone_number='+'+phone_number
            print("speak the message")
            speak('speak the message')
            message=recognize_said_words()
            print("when to send note time must be of 2 minutes later")
            speak('when to send note time must be of 2 minutes later')
            hours=recognize_said_words()
            print("minutes")
            speak('minutes')
            minutes=recognize_said_words()
            sendwhatmsg(phone_number,message,int(hours),int(minutes))
            #Send messages on whats app
        elif 'track covid-19' in user_input:
            from covid_19_tracker import tracker
            tracker()
            #covid19 tracker and represent on gui=Vikram
        elif 'search on google' in user_input:
            from pywhatkit import search
            new_user_input=get_command('search on google ',user_input)
            search(new_user_input)
            #→  Searching on google
        elif 'play chess' in user_input:
            #Chess = Simran
            print("opening chess lets play")
            speak('opening chess lets play')
            from os import system
            system('python gui.py')
        elif 'detect langauge' in user_input:
            #detect language
            print("speak the sentence")
            speak('speak the sentence')
            to_be_detected=recognize_said_words()
            from langdetect import detect
            print(detect(to_be_detected))
            speak(detect(to_be_detected))
        elif 'translate' in user_input:
            #Translater
            print("speak the sentence which you want to translate")
            speak('speak the sentence which you want to translate')
            to_be_translated=recognize_said_words()
            #pip or conda install googletrans
            from googletrans import Translator
            translator = Translator()
            #you can specify the translate languege
            result = translator.translate(to_be_translated,dest='en')
            print(result.text)
            speak(result.text)
        elif 'check my internet speed' in user_input:
            from pyautogui import press,typewrite
            from time import sleep
            from os import system
            system('&speedtest.exe')
        elif 'alarm' in user_input:
            get_command('alarm',user_input)
            dTimeA = datefinder.find_dates(user_input)
            for mat in dTimeA:
                print(mat)
            stringA = str(mat)
            timeA = stringA[11:]
            hourA = timeA[:-6]
            hourA = int(hourA)
            minA = timeA[3:-3]
            minA = int(minA)
        elif 'capture my image' in user_input:
            import cv2
            camera = cv2.VideoCapture(0)
            return_value, image = camera.read()
            cv2.imwrite('image1.png', image)
            del(camera)
        elif 'play ludo' in user_input:
            from os import system
            system('python ludo.py')
        elif 'play snake game' in user_input:
            from os import system
            system('python snake.py')
        elif 'play snake game' in user_input:
            from os import system
            system('python snake_game.py')
        elif 'send email' or 'send mail' or 'mail' in user_input:
            send_email()
        elif 'shutdown' in user_input:
            from pywhatkit import shutdown
            speak('going to shut  down your system in 30 seconds')
            shutdown(time=30)
        elif 'exit' == user_input:
            return 0

#run_this()
#send_email()
run_this()

#movie downloader
