# ludo
This Is a Classical LUDO Game made  by me using tkinter module in python.
It uses very simple python code.
I created the board using tkinter canvas and the dice and the pawns are of buttons.

SO PLESE ENJOY THIS GAME!!!
